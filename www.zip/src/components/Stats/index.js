export { default } from "./Stats";
