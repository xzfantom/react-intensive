export { default } from "./Footer";
