export { default } from "./InputName";
