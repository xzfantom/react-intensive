import Navigation from "./components/Navigation";

const App = () => (
  <>
    <Navigation />
  </>
);

export default App;
